import React from "react";

// Redux (you imported dispatch but not used, so I removed it)
const AppLayout = ({ children }) => {
  return <>{children}</>;
};

export default AppLayout;
