import React from "react";

const Blank = ({ children }) => {
  return (
    <>
      <div>{children}</div>
    </>
  );
};

export default Blank;
