import React from 'react'
import HomeBannerSlider from '../../slider/HomeBannerSlider'
const OrganizerEvents = () => {
  return (
    <div>
      <HomeBannerSlider />
    </div>
  )
}

export default OrganizerEvents
