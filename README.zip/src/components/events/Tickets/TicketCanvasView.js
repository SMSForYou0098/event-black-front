import React, { useEffect, useRef, useState, useCallback, forwardRef, useImperativeHandle } from 'react';
import { fabric } from 'fabric-pure-browser';
import { api } from '@/lib/axiosInterceptor';
import { useMyContext } from "@/Context/MyContextProvider";
import QRCode from 'qrcode';

/**
 * TicketCanvasView - A reusable canvas component for rendering tickets
 * 
 * Canvas size: 300px width × 600px height
 */
const TicketCanvasView = forwardRef((props, ref) => {
    const {
        showDetails,
        ticketNumber,
        preloadedImage,
        onReady,
        onError,
        ticketData,
    } = props;


    const { convertTo12HourFormat, formatDateRange } = useMyContext();
    const canvasRef = useRef(null);
    const fabricCanvasRef = useRef(null);

    // Extract values from ticketData - handle both single and multiple booking structures
    // For multiple bookings (quantity > 1), data is in bookings[0]
    // For single booking, data is at parent level
    const ticket = ticketData?.ticket || ticketData?.bookings?.[0]?.ticket || {};
    const event = ticket?.event || {};
    const venue = event?.venue || {};
    const user = ticketData?.user || ticketData?.attendee || ticketData?.bookings?.[0]?.user || ticketData?.bookings?.[0]?.attendee || {};

    // Derived values
    const ticketName = ticket?.name || 'Ticket Name';
    const userName = user?.name || user?.Name || 'User Name';
    // Aggregate seat names for group tickets
    const seatNames = ticketData?.bookings?.length > 1
        ? ticketData.bookings.map(b => b.seat_name || b.event_seat_status?.seat_name).filter(Boolean).join(', ')
        : null;
    const number = seatNames || ticketData?.seat_name || ticketData?.event_seat_status?.seat_name || 'N/A';
    const address = venue?.address || event?.address || 'Address Not Specified';
    const ticketBG = ticket?.background_image || '';
    const date = formatDateRange?.(ticketData?.booking_date || event?.date_range) || 'Date Not Available';
    const time = convertTo12HourFormat?.(event?.start_time) || 'Time Not Set';
    const OrderId = ticketData?.order_id || ticketData?.token || 'N/A';
    const title = event?.name || 'Event Name';
    const bookingType = ticketData?.booking_type || 'Online';

    // State
    const [imageUrl, setImageUrl] = useState(null);
    const [qrDataUrl, setQrDataUrl] = useState(null);
    const [isCanvasReady, setIsCanvasReady] = useState(false);

    const textColor = '#000';
    const CANVAS_WIDTH = 300;
    const CANVAS_HEIGHT = 600;

    // Expose methods to parent via ref
    useImperativeHandle(ref, () => ({
        download: () => downloadCanvas(),
        print: () => printCanvas(),
        isReady: () => isCanvasReady,
        getDataURL: (options = {}) => {
            const canvas = fabricCanvasRef.current;
            if (!canvas) return null;
            return canvas.toDataURL({
                format: 'jpeg',
                quality: 0.9,
                multiplier: 2,
                ...options
            });
        }
    }), [isCanvasReady]);

    // 1. Handle Image URL
    useEffect(() => {
        let active = true;
        let localUrl = null;

        const fetchImage = async () => {
            if (preloadedImage && ticketBG && ticketBG.startsWith('blob:')) {
                if (active) setImageUrl(ticketBG);
                return;
            }

            try {
                const response = await api.post(
                    'get-image/retrive',
                    { path: ticketBG },
                    { responseType: 'blob' }
                );
                if (active) {
                    localUrl = URL.createObjectURL(response.data);
                    setImageUrl(localUrl);
                }
            } catch (error) {
                console.error('Image fetch error:', error);
                onError?.('Failed to load ticket background');
            }
        };

        if (ticketBG) {
            fetchImage();
        }

        return () => {
            active = false;
            if (localUrl && !preloadedImage) {
                URL.revokeObjectURL(localUrl);
            }
        };
    }, [ticketBG, preloadedImage, onError]);

    // 2. Generate QR Code
    useEffect(() => {
        if (!OrderId) return;

        QRCode.toDataURL(OrderId, {
            width: 150,
            margin: 1,
            errorCorrectionLevel: 'H'
        })
            .then(url => {
                setQrDataUrl(url);
            })
            .catch(err => {
                console.error('QR Generation Error', err);
                onError?.('Failed to generate QR code');
            });
    }, [OrderId, onError]);

    // Helper Functions
    const loadFabricImage = useCallback((url, options = {}) => {
        return new Promise((resolve, reject) => {
            fabric.Image.fromURL(
                url,
                (img) => {
                    if (img && img.getElement()) {
                        resolve(img);
                    } else {
                        reject(new Error('Failed to load image'));
                    }
                },
                { crossOrigin: 'anonymous', ...options }
            );
        });
    }, []);

    const centerText = useCallback((text, fontSize, fontFamily, canvas, top, options = {}) => {
        const textObj = new fabric.Text(text || '', {
            fontSize,
            fontFamily,
            top: top,
            fill: textColor,
            selectable: false,
            evented: false,
            originX: 'center',
            left: canvas.width / 2,
            ...options
        });
        canvas.add(textObj);
        return textObj;
    }, [textColor]);

    // 3. Draw Canvas
    useEffect(() => {
        if (!canvasRef.current) return;
        if (!imageUrl && !qrDataUrl) return;

        if (fabricCanvasRef.current) {
            fabricCanvasRef.current.dispose();
        }

        const canvas = new fabric.Canvas(canvasRef.current, {
            enableRetinaScaling: true
        });
        fabricCanvasRef.current = canvas;

        const draw = async () => {
            try {
                // Set fixed canvas dimensions
                canvas.setDimensions({ width: CANVAS_WIDTH, height: CANVAS_HEIGHT });

                if (imageUrl) {
                    const img = await loadFabricImage(imageUrl);
                    canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas), {
                        scaleX: CANVAS_WIDTH / img.width,
                        scaleY: CANVAS_HEIGHT / img.height
                    });
                } else {
                    canvas.setBackgroundColor('#ffffff', canvas.renderAll.bind(canvas));
                }

                // Event name at top (above QR code)
                if (showDetails) {
                    centerText(title, 14, 'Arial', canvas, 20, { fontWeight: 'bold' });
                }

                // Add QR code
                if (qrDataUrl) {
                    const qrImg = await loadFabricImage(qrDataUrl);
                    const qrCodeSize = 85;
                    const padding = 4;
                    const qrPositionX = (CANVAS_WIDTH / 2) - (qrCodeSize / 2) + 5;
                    const qrPositionY = 62;

                    const qrBackground = new fabric.Rect({
                        left: qrPositionX - padding,
                        top: qrPositionY - padding,
                        width: qrCodeSize + padding * 2,
                        height: qrCodeSize + padding * 2,
                        fill: 'white',
                        selectable: false,
                        evented: false,
                        rx: 4,
                        ry: 4
                    });

                    qrImg.set({
                        left: qrPositionX,
                        top: qrPositionY,
                        selectable: false,
                        evented: false,
                        scaleX: qrCodeSize / qrImg.width,
                        scaleY: qrCodeSize / qrImg.height,
                    });

                    canvas.add(qrBackground);
                    canvas.add(qrImg);
                }

                // Add details
                if (showDetails) {
                    let currentY = 170;

                    // Ticket name (larger and bold)
                    centerText(ticketName, 24, 'Arial', canvas, currentY, { fontWeight: 'bold' });
                    currentY += 30;

                    // Label (I) or (G)
                    if (props.ticketLabel) {
                        centerText(props.ticketLabel + (ticketNumber ? ' ' + ticketNumber : ''), 16, 'Arial', canvas, currentY, { fontWeight: 'bold', fill: '#666' });
                        currentY += 25;
                    } else {
                        currentY += 10;
                    }

                    // Booking Type
                    centerText(` ${bookingType.toUpperCase()}`, 18, 'Arial', canvas, currentY);
                    currentY += 30;

                    // User number/seat
                    if (number !== 'N/A') {
                        centerText(`Seat/Number: ${number}`, 15, 'Arial', canvas, currentY);
                        currentY += 30;
                    }

                    // Entry time and Date on same line
                    const entryTimeText = new fabric.Text(`TIME:\n${time}`, {
                        left: 15,
                        top: currentY,
                        fontSize: 15,
                        fontFamily: 'Arial',
                        fill: textColor,
                        selectable: false,
                        evented: false,
                        fontWeight: 'bold',
                        textAlign: 'left',
                    });
                    canvas.add(entryTimeText);

                    // Date range with wrapping (on the right side, same line)
                    const dateStartX = 150; // Position date on the right side
                    const eventDateText = new fabric.Textbox(`DATE:\n${date}`, {
                        left: dateStartX,
                        top: currentY,
                        fontSize: 15,
                        fontFamily: 'Arial',
                        fill: textColor,
                        selectable: false,
                        evented: false,
                        fontWeight: 'bold',
                        width: CANVAS_WIDTH - dateStartX - 15, // Remaining width
                        lineHeight: 1.4,
                        textAlign: 'left',
                    });
                    canvas.add(eventDateText);

                    // Calculate height based on the taller element
                    const timeHeight = entryTimeText.height || 20;
                    const dateHeight = eventDateText.height || 20;
                    const maxHeight = Math.max(timeHeight, dateHeight);
                    currentY += maxHeight + 25;

                    // Venue/Address - wrapped to multiple lines for readability
                    const venueLabel = new fabric.Text('', {
                        left: 15,
                        top: currentY,
                        fontSize: 18,
                        fontFamily: 'Arial',
                        fill: textColor,
                        fontWeight: 'bold',
                        selectable: false,
                        evented: false,
                    });
                    canvas.add(venueLabel);
                    currentY += 20;

                    const eventVenueText = new fabric.Textbox(address, {
                        left: 15,
                        top: currentY,
                        fontSize: 16,
                        fontFamily: 'Arial',
                        fill: textColor,
                        selectable: false,
                        evented: false,
                        width: CANVAS_WIDTH - 30,
                        lineHeight: 1.5,
                        textAlign: 'left',
                    });
                    canvas.add(eventVenueText);

                    // Order ID at bottom
                }

                canvas.renderAll();
                setIsCanvasReady(true);
                onReady?.();

            } catch (error) {
                console.error('Error drawing canvas:', error);
                onError?.('Failed to render ticket');
            }
        };

        draw();

        return () => {
            if (fabricCanvasRef.current) {
                fabricCanvasRef.current.dispose();
                fabricCanvasRef.current = null;
            }
        };
    }, [imageUrl, qrDataUrl, showDetails, ticketName, userName, number, address, date, time, title, ticketNumber, bookingType, OrderId, centerText, loadFabricImage, textColor, onReady, onError, props.ticketLabel]);

    // Download functionality
    const downloadCanvas = () => {
        try {
            const canvas = fabricCanvasRef.current;
            if (!canvas) throw new Error('Canvas not ready');

            const dataURL = canvas.toDataURL({
                format: 'jpeg',
                quality: 0.9,
                multiplier: 2
            });

            const link = document.createElement('a');
            link.href = dataURL;
            link.download = `ticket_${OrderId || 'event'}.jpg`;
            link.click();
            return true;

        } catch (error) {
            console.error('Download error:', error);
            onError?.('Failed to download ticket');
            return false;
        }
    };

    const printCanvas = () => {
        try {
            const canvas = fabricCanvasRef.current;
            if (!canvas) throw new Error('Canvas not ready');

            const dataURL = canvas.toDataURL({
                format: 'png',
                multiplier: 1.5
            });

            const printWindow = window.open('', '', 'width=800,height=600');
            const printImage = new Image();
            printImage.src = dataURL;

            printImage.onload = () => {
                printWindow.document.write('<html><head><title>Print Ticket</title></head><body style="text-align:center;">');
                printWindow.document.body.appendChild(printImage);
                printWindow.document.write('</body></html>');
                printWindow.document.close();
                printWindow.focus();
                setTimeout(() => {
                    printWindow.print();
                    printWindow.close();
                }, 250);
            };
            return true;

        } catch (error) {
            console.error('Print error:', error);
            onError?.('Failed to print ticket');
            return false;
        }
    };

    return (
        <div className="ticket-canvas-view">
            <div style={{ display: 'flex', justifyContent: 'center', width: '100%', minHeight: '300px' }}>
                <canvas ref={canvasRef} />
            </div>
        </div>
    );
});

TicketCanvasView.displayName = 'TicketCanvasView';

export default TicketCanvasView;