import React from 'react';
import { Row, Col } from 'react-bootstrap';
import AvailableRewards from './AvailableRewards';
import PointsHistory from './PointsHistory';

const RewardsTab = ({ rewards, pointsHistory }) => (
  null
  // <Row>
  //   <Col lg={6}>
  //     <AvailableRewards rewards={rewards} />
  //   </Col>
  //   <Col lg={6}>
  //     <PointsHistory pointsHistory={pointsHistory} />
  //   </Col>
  // </Row>
);

export default RewardsTab;