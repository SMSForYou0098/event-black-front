import React from 'react'

const BookingPage = () => {
  return (
    <div className='mt-5 pt-3'>
      hello
    </div>
  )
}

export default BookingPage
