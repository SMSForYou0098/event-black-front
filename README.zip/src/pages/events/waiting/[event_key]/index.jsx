import React, { useEffect, useState, useRef } from 'react';
import { Container, Card, Spinner } from 'react-bootstrap';
import { useRouter } from 'next/router';
import { useMyContext } from '@/Context/MyContextProvider';
import { CheckCircle, XCircle, Clock } from 'lucide-react';
import Image from 'next/image';

const PaymentWaiting = () => {
    const router = useRouter();
    const { event_key, session_id } = router.query;
    const { ErrorAlert, authToken } = useMyContext();

    const [status, setStatus] = useState('pending'); // pending, confirmed, failed
    const [message, setMessage] = useState('Processing your payment...');
    const [errorMessage, setErrorMessage] = useState('');
    const eventSourceRef = useRef(null);

    useEffect(() => {
        if (!session_id || !event_key) return;

        // Try EventSource for real-time updates
        try {
            // const eventSource = new EventSource(`http://192.168.0.166:8000/api/dark/payments/status-stream/ORD123`);
            const eventSource = new EventSource(`${process.env.NEXT_PUBLIC_API_PATH}payments/status-stream/${session_id}?token=${authToken}`);
            eventSourceRef.current = eventSource;
            eventSource.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    console.log(data, "SSE data received");

                    if (data.payment_status === 'confirmed' || data.payment_status === 'success') {
                        setStatus('confirmed');
                        setMessage('Payment Successful!');
                        eventSource.close();

                        // Navigate to summary page
                        setTimeout(() => {
                            router.push(
                                `/events/summary/${encodeURIComponent(event_key)}?session_id=${encodeURIComponent(session_id)}`
                            );
                        }, 1500);
                    } else if (data.status === 'failed') {
                        setStatus('failed');
                        setErrorMessage(data.message || 'Payment failed. Please try again.');
                        eventSource.close();
                    }
                } catch (parseError) {
                    console.error('Error parsing SSE data:', parseError);
                }
            };

            eventSource.onerror = (error) => {
                console.error('EventSource error:', error);
                eventSource.close();
                setStatus('failed');
                setErrorMessage('Connection lost. Please refresh the page.');
            };

        } catch (error) {
            console.error('EventSource not supported or failed:', error);
            setStatus('failed');
            setErrorMessage('Unable to connect. Please refresh the page.');
        }

        // Cleanup
        return () => {
            if (eventSourceRef.current) {
                eventSourceRef.current.close();
            }
        };
    }, [session_id, event_key]);

    const getStatusIcon = () => {
        switch (status) {
            case 'confirmed':
                return <CheckCircle size={80} className="text-success" />;
            case 'failed':
                return <XCircle size={80} className="text-danger" />;
            default:
                return <Clock size={80} className="text-warning" />;
        }
    };

    const handleRetry = () => {
        router.push(`/events/cart/${event_key}`);
    };

    const handleViewBookings = () => {
        router.push('/my-bookings');
    };

    if (!session_id) {
        return (
            <div className="cart-page">
                <Container className="py-5 text-center">
                    <p className="text-muted">Loading...</p>
                </Container>
            </div>
        );
    }

    return (
        <div className="cart-page">
            <Container className="py-5">
                <Card className="custom-dark-bg text-center mx-auto" style={{ maxWidth: '500px' }}>
                    <Card.Body className="p-5">
                        {/* Status Icon */}
                        <div className="mb-4">
                            {status === 'pending' ? (
                                <div className="position-relative d-inline-block">
                                    <Image
                                        src="/assets/stock/payment_processing.gif"
                                        alt="Processing"
                                        width={120}
                                        height={120}
                                        className="rounded"
                                    />
                                </div>
                            ) : (
                                getStatusIcon()
                            )}
                        </div>

                        {/* Status Message */}
                        <h4 className="text-white mb-3">
                            {status === 'pending' && 'Processing Payment...'}
                            {status === 'confirmed' && 'Payment Successful!'}
                            {status === 'failed' && 'Payment Failed'}
                        </h4>

                        <p className="text-muted mb-4">
                            {status === 'pending' && 'Please wait while we confirm your payment.'}
                            {status === 'confirmed' && 'Redirecting to your booking summary...'}
                            {status === 'failed' && errorMessage}
                        </p>

                        {/* Loading Spinner for pending */}
                        {status === 'pending' && (
                            <div className="mb-4">
                                <Spinner animation="border" variant="primary" size="sm" />
                                <span className="ms-2 text-muted small">Waiting for confirmation...</span>
                            </div>
                        )}

                        {/* Action Buttons for failed status */}
                        {status === 'failed' && (
                            <div className="d-flex gap-3 justify-content-center">
                                <button
                                    className="btn btn-outline-secondary"
                                    onClick={handleViewBookings}
                                >
                                    View Bookings
                                </button>
                                <button
                                    className="btn btn-primary"
                                    onClick={handleRetry}
                                >
                                    Try Again
                                </button>
                            </div>
                        )}
                    </Card.Body>
                </Card>
            </Container>
        </div>
    );
};

PaymentWaiting.layout = 'events';
export default PaymentWaiting;
