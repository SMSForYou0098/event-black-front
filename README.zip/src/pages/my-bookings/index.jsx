import React from 'react'
import BookingsTab from '../../components/events/Profile/BookingsTab'

const MyBookings = () => {
  return (
    <div>
      <BookingsTab />
    </div>
  )
}

export default MyBookings