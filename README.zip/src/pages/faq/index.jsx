import React from 'react'
import FAQPage from '../../components/events/extra_pages/faq'

const Faq = () => {
    
  return (
    <div>
      <FAQPage />
    </div>
  )
}

export default Faq
