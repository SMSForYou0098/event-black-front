export const state = {
    // shop
    heroSlider: [],
    category: [],
    products: [],
    shopBannerSlider: [],
    newProduct: [],
    bestseller: [],
    myWishlist: [],
    myCart: []
}