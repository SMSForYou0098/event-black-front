import { streamitSlice } from './reducers'

export const {
    set_breadcrumb,
} = streamitSlice.actions;
export default streamitSlice.actions