import React from 'react'

const EventsGrid = (props) => {
    const {} = props;
  return (
    <div>
      
    </div>
  )
}

export default EventsGrid
